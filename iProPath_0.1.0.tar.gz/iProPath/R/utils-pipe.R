#' Pipe operator
#'
#' See \code{\link[magrittr]{%>%}}.
#'
#' @name %>%
#' @rdname pipe
#' @keywords internal
#' @importFrom magrittr %>%
NULL
